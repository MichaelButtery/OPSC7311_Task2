package com.example.catit1;

public class Category {
    private String categoryName;
    private int goalItems;
    public Category(){

    }
    public Category(String categoryName, String goalItems) {
        this.categoryName = categoryName;
        this.goalItems = Integer.parseInt(goalItems);
    }
    public String getCategoryName() {
        return categoryName;
    }
    public int getGoalItems() {
        return goalItems;
    }
}
