package com.example.catit1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    //private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //auth = FirebaseAuth.getInstance();

        //FirebaseUser user = auth.getCurrentUser();

        //if(user != null){
        //finish();
        //startActivity(new Intent(this, dashboardActivity.class));
        //}

        Button btnReg=findViewById(R.id.SignUpMain);
        btnReg.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                v.setEnabled(false);
                Toast.makeText(MainActivity.this,"Going to Register",Toast.LENGTH_LONG).show();
                Intent i = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(i);
            }
        });

        Button btnLogin=findViewById(R.id.LoginButtonMain);
        btnLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                v.setEnabled(false);
                Toast.makeText(MainActivity.this,"Going to Log In",Toast.LENGTH_LONG).show();
                Intent i = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });
}}
