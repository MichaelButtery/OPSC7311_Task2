package com.example.catit1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class viewInventoryActivity extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private RecyclerView mrecyclerview;
    private DatabaseReference mdatabaseReference;
    private TextView totalnoofitem, displayBox;
    private Button backButton;
    private int counttotalnoofitem =0;
    private ArrayList <Category> categoryArray= new ArrayList<Category>();
    private ArrayList <Items> ItemArray= new ArrayList<Items>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_inventory);
        totalnoofitem= findViewById(R.id.totalnoitem);
        backButton = findViewById(R.id.BackBTNView);
        firebaseAuth = FirebaseAuth.getInstance();
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
        FirebaseUser CurrentUser = firebaseAuth.getCurrentUser();
        displayBox = findViewById(R.id.displaybox);
        boolean done=false;

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(viewInventoryActivity.this, dashboardActivity.class));
            }

        });

        databaseReference.child("users").child(CurrentUser.getUid()).child("categories").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                } else {
                    String fullCat = String.valueOf(task.getResult().getValue());   //{Technology={goalItems=5, categoryName=Technology}, Food={goalItems=12, categoryName=Food}}
                    String[] catSplit = fullCat.split("}");

                    for (int i = 0; i < catSplit.length; i++) {
                        String[] catSplitAgain = catSplit[i].split(Pattern.quote("="));
                        String CATEGORYNAME = catSplitAgain[3];
                        String[] catSplitAgainAgain = catSplitAgain[2].split(",");
                        String GOALITEMS= catSplitAgainAgain[0];
                        Category temp = new Category(GOALITEMS, CATEGORYNAME);

                        categoryArray.add(temp);
                        displayBox.append(CATEGORYNAME+" : \t"+GOALITEMS);
                    }

                }
            }
        });

        for(Category c : categoryArray)
        {
            databaseReference.child("users").child(CurrentUser.getUid()).child("categories").child(c.getCategoryName()).child("items").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (!task.isSuccessful()) {
                        Log.e("firebase", "Error getting data", task.getException());
                    } else {
                        String fullCat = String.valueOf(task.getResult().getValue());
                        String[] catSplit = fullCat.split("}");

                        for (int i = 0; i < catSplit.length; i++) {
                            String[] catSplitAgain = catSplit[i].split("=");
                            String DATE = catSplitAgain[4];
                            String[] catSplitAgainAgain1 = catSplitAgain[2].split(",");
                            String NAME= catSplitAgainAgain1[0];
                            String[] catSplitAgainAgain2 = catSplitAgain[3].split(",");
                            String CATEGORY= catSplitAgainAgain2[0];
                            Items temp = new Items(NAME, CATEGORY, DATE);

                            ItemArray.add(temp);
                            displayBox.append("\n\tName : \t"+NAME+"\n\tCategory : \t"+CATEGORY+"\n\tDate : \t"+DATE+"\n");
                        }
                    }
                }
            });
        }
    }
}