package com.example.catit1;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class additemActivity extends AppCompatActivity {
    private EditText itemname;
    private AutoCompleteTextView itemcategory;
    private TextView itemdate;
    private FirebaseAuth firebaseAuth;
    public static TextView resulttextview;
    private Button photoButton, additemtodatabase, backButton, addCategory;
    private DatabaseReference databaseReference;
    private ArrayList <Category> categoryArray= new ArrayList<Category>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additem);
        firebaseAuth = FirebaseAuth.getInstance();

        boolean firstOpen=true;
        databaseReference = FirebaseDatabase.getInstance().getReference();


        resulttextview = findViewById(R.id.edititemname);
        additemtodatabase = findViewById(R.id.additembuttontodatabase);
        itemname = findViewById(R.id.edititemname);
        itemcategory= findViewById(R.id.editcategory);
        itemdate = findViewById(R.id.editdate);
        photoButton = findViewById(R.id.buttonPhoto);
        backButton = findViewById(R.id.BackBTNAddItem);
        addCategory = findViewById(R.id.addCategory);

        //-------------------code attribution---------------------------
        //The following method was taken from StackOverFlow:
        //Author: RaMeSh
        //Link: https://stackoverflow.com/questions/31052436/android-edittext-with-drop-down-list


        itemcategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getCategories();

            }
        });

        if(firstOpen==true)
        {
            getCategories();
            Object objectArray[]=categoryArray.toArray();
            String FullCategoryArray[]=new String[categoryArray.size()];
            int pos=0;

            for(Object obj : objectArray)
            {
                FullCategoryArray[pos]=obj.toString();
                pos++;
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_singlechoice, FullCategoryArray);
            AutoCompleteTextView acTextView = (AutoCompleteTextView) itemcategory;
            acTextView.setThreshold(1);
            acTextView.setAdapter(adapter);
            Log.e("TEST","SUCCESS");
            firstOpen=false;
        }
        else
        {
            Log.e("TEST","Fail its too empty");
        }


        //------------------end--------------------------------------------

        photoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //startActivity(new Intent(getApplicationContext(), PhotoActivity.class));
            }
        });

        additemtodatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                additem();
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(additemActivity.this, dashboardActivity.class));
            }
        });

        addCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(additemActivity.this, addCategoryActivity.class));
            }
        });
    }


    public void getCategories() {
        FirebaseUser CurrentUser = firebaseAuth.getCurrentUser();
        categoryArray.clear();

        databaseReference.child("users").child(CurrentUser.getUid()).child("categories").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                } else {
                    String fullCat = String.valueOf(task.getResult().getValue());   //{Technology={goalItems=5, categoryName=Technology}, Food={goalItems=12, categoryName=Food}}
                    String[] catSplit = fullCat.split("}");

                    for (int i = 0; i < catSplit.length; i++) {
                        String[] catSplitAgain = catSplit[i].split("=");
                        String CATEGORYNAME = catSplitAgain[3];
                        String[] catSplitAgainAgain = catSplitAgain[2].split(",");
                        String GOALITEMS = catSplitAgainAgain[0];
                        Category temp = new Category(GOALITEMS, CATEGORYNAME);

                        categoryArray.add(temp);
                    }
                }
            }
        });
        return;
    }

    // addding item to databse
    public  void additem(){
        String itemnameValue = itemname.getText().toString();
        String itemcategoryValue = itemcategory.getText().toString();
        String itemdateValue = itemdate.getText().toString();

        if(TextUtils.isEmpty(itemnameValue)&&TextUtils.isEmpty(itemcategoryValue)&&TextUtils.isEmpty((CharSequence) itemdate)){
            Toast.makeText(additemActivity.this,"Please Fill all the fields",Toast.LENGTH_SHORT).show();
        }
        else {

            FirebaseUser CurrentUser = firebaseAuth.getCurrentUser();

            Items currentItem=new Items(itemnameValue,itemcategoryValue,itemdateValue);
            databaseReference.child("users").child(CurrentUser.getUid()).child("categories").child(itemcategoryValue).child("items").child(itemnameValue).setValue(currentItem);    //WRITTEN ITEM TO DATABASE

            Log.e("firebase", currentItem.getItemname() +"ADDED TO DATABASE");
            Toast.makeText(additemActivity.this,currentItem.getItemname() + " item added to database under " + currentItem.getItemcategory(),Toast.LENGTH_SHORT).show();

        }
    }
}
