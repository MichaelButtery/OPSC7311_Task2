package com.example.catit1;

public class User {
    public String  email,password;

    public User(){

    }

    public User(String password, String email) {
        this.password = password;
        this.email = email;

    }
}
