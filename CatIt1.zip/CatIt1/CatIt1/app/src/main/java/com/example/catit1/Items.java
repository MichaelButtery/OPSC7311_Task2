package com.example.catit1;

import android.widget.EditText;
import android.widget.TextView;

public class Items {
    // Name,Date,Photo
    private String itemname;
    private String itemcategory;
    private String itemdate;




    public Items(EditText itemnameValue, EditText itemcategoryValue, TextView itemdateValue){

}

public Items(String itemname,String itemcategory,String itemdate){

    this.itemname=itemname;
    this.itemcategory=itemcategory;
    this.itemdate=itemdate;

}


    public String getItemname() {
        return itemname;
    }

    public String getItemcategory() {
        return itemcategory;
    }

    public String getItemdate() {
        return itemdate;
    }


}